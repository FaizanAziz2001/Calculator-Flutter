

import 'package:flutter/material.dart';

const Color colorDark = Color(0xFF374352);
const Color colorLight = Color(0xFFe6eeff);

class CalculatorButton extends StatefulWidget {
  final bool darkModeP;
  final BorderRadius borderRadiusP;
  final EdgeInsetsGeometry paddingP;
  final String text;
  final Function callback;

  CalculatorButton(
      {required this.darkModeP,
      required this.borderRadiusP,
      this.paddingP = const EdgeInsets.all(0),
      this.text = "",
      required this.callback});

  @override
  State<CalculatorButton> createState() => _CalculatorButton();
}

class _CalculatorButton extends State<CalculatorButton> {
  @override
  Widget build(BuildContext context) {
    return Listener(
      child: Container(
        margin: EdgeInsets.fromLTRB(0, 5.0, 0, 5.0),
        decoration:
            BoxDecoration(borderRadius: widget.borderRadiusP, boxShadow: [
          BoxShadow(
            color: widget.darkModeP
                ? Colors.blueGrey.shade900
                : Colors.blueGrey.shade200,
            offset: Offset(4.0, 4.0),
            blurRadius: 2.0,
            spreadRadius: 1,
          ),
        ]),
        child: TextButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(
                widget.darkModeP ? colorDark : colorLight),
            padding:
                MaterialStateProperty.all<EdgeInsetsGeometry>(widget.paddingP),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
              borderRadius: widget.borderRadiusP,
              side: BorderSide(
                  color: widget.darkModeP ? Colors.black12 : Colors.white),
            )),
          ),
          onPressed: () => widget.callback(widget.text),
          child: Text(
            widget.text,
            style: TextStyle(
              color: widget.darkModeP ? colorLight : colorDark,
            ),
          ),
        ),
      ),
    );
  }
}
