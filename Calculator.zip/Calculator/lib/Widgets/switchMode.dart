import 'package:calculator/Widgets/calculator_button.dart';
import 'package:flutter/material.dart';

class switchMode extends StatelessWidget {

  final bool darkMode;
  final Function callback;

  const switchMode({super.key, required this.darkMode,required this.callback
});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 10.0, 0, 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CalculatorButton(
              darkModeP: darkMode,
              text: "AC",
              borderRadiusP: BorderRadius.circular(30.0),
              paddingP: const EdgeInsets.fromLTRB(10.0, 15.0, 10.0, 15.0),
              callback: callback),
          Container(
            width: 100,
            padding: const EdgeInsets.all(10.0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30.0),
                border:
                Border.all(color: darkMode ? Colors.black12 : Colors.white),
                color: darkMode ? colorDark : colorLight,
                boxShadow: [
                  BoxShadow(
                    color: darkMode
                        ? Colors.blueGrey.shade900
                        : Colors.blueGrey.shade200,
                    offset: const Offset(4.0, 4.0),
                    blurRadius: 2.0,
                    spreadRadius: 1,
                  ),
                ]),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Icon(
                    Icons.wb_sunny,
                    color: darkMode ? Colors.grey : Colors.redAccent,
                  ),
                  Icon(
                    Icons.nightlight_round,
                    color: darkMode ? Colors.green : Colors.grey,
                  ),
                ]),
          ),
        ],
      ),
    );

  }
}
