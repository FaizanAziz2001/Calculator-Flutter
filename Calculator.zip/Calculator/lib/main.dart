import 'dart:math';

import 'package:calculator/Widgets/calculator_button.dart';
import 'package:calculator/Widgets/switchMode.dart';
import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculator',
      home: HomePage(),
    );
  }
}

const Color colorDark = Color(0xFF374352);
const Color colorLight = Color(0xFFe6eeff);
const double padding = 20;
const double radius = 30.0;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool darkMode = true;
  String output = "Output";
  String working = "";

  void button_click(String val) {
    if (val == "=") {
      Parser p = Parser();
      Expression exp = p.parse(working);
      ContextModel cm = ContextModel();
      double eval = exp.evaluate(EvaluationType.REAL, cm);

      output = eval.toString();
    } else if (val == "AC") {
      working = "";
      output = "Output";
    } else if (val == "C") {
      working = working.substring(0, working.length - 1);
    } else if (val == "sqrt") {
      working += "^(1/2)";
    } else if (val == "cbrt") {
      working += "^(1/3)";
    } else {
      working += val;
    }
    setState(() {
      working;
      output;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkMode ? colorDark : colorLight,
      body: Container(
          margin: EdgeInsets.fromLTRB(10.0, 30.0, 10.0, 10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    darkMode ? darkMode = false : darkMode = true;
                  });
                },
                child: switchMode(darkMode: darkMode,callback: button_click,),
              ),
              Expanded(
                child: Container(
                  alignment: Alignment.centerRight,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    reverse: true,
                    child: Text(
                      working,
                      style: TextStyle(
                        fontSize: 40,
                        color: darkMode ? colorLight : colorDark,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "=",
                        style: TextStyle(
                          color: darkMode ? colorLight : colorDark,
                        ),
                      ),
                      Flexible(
                        child: FittedBox(
                          child: Text(
                            output,
                            style: TextStyle(
                              fontSize: 40,
                              color: darkMode ? colorLight : colorDark,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '!',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '^',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '.',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '%',
                      callback: button_click),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: 'cbrt',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: 'sqrt',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '^3',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '^2',
                      callback: button_click),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '7',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '8',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '9',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '/',
                      callback: button_click),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '4',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '5',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '6',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '*',
                      callback: button_click),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '1',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '2',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '3',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '-',
                      callback: button_click),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: 'C',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '0',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '=',
                      callback: button_click),
                  CalculatorButton(
                      darkModeP: darkMode,
                      borderRadiusP: BorderRadius.circular(radius),
                      paddingP: const EdgeInsets.all(padding),
                      text: '+',
                      callback: button_click),
                ],
              )
            ],
          )),
    );
  }

}


